# Yander logo kit

The official Y mark in every format you'll need. The Y is hand-drawn,
organic — two upper arms diverge like a fork in the path, the stem winds
down like a country road, and terminates in a small dot like a
destination pin.

## Folder map

- **svg/** — Vector source, infinitely scalable. Use this for anything
  where you control the rendering (websites, slide decks, vector apps).
  - `yander-y.svg` — master with `currentColor`, recolour via CSS `color`
  - `yander-y-mint.svg` (default app colour)
  - `yander-y-paper.svg` (cream — for dark backgrounds)
  - `yander-y-ink.svg` (near-black — for light backgrounds)
  - `yander-y-white.svg` (pure white — for photos or rich backgrounds)
  - `yander-y-amber.svg` (warm accent)
- **png/** — Raster export at common sizes (16–2048 px) for every
  colour variant. Use for places that can't load SVG (legacy email
  clients, some app stores, file uploads).
- **favicon/** — Web favicon set: `.ico` with embedded 16/32/48 px;
  individual PNGs at 16/32/48/64/128/180/256; an `apple-touch-icon.png`
  baked onto the forest background (iOS strips alpha).
- **lockup/** — Y + "yander" wordmark horizontal lockups for headers,
  email signatures, slide covers. Variants on transparent (mint, paper,
  ink) plus one canonical version on the forest background.
- **app-icon/** — 1024×1024 squircle app icon (mint Y on forest) plus
  smaller raster exports. Drop straight into App Store Connect / Play
  Console asset slots.
- **social/**
  - `yander-og-1200x630.png` — Open Graph / Twitter share card with
    tagline "The route less taken." Drop into og:image meta tags or
    upload to LinkedIn/Twitter/Facebook for pinned posts.
  - `yander-avatar-1024.png` — square avatar tile for Instagram,
    X/Twitter, LinkedIn company page.

## Colour tokens

| Token   | Hex      | Use                                        |
|---------|----------|--------------------------------------------|
| Mint    | `#5cb992`| Primary brand colour (the app Y)           |
| Paper   | `#f7f3ec`| Cream — text/Y on dark backgrounds         |
| Ink     | `#2b231d`| Near-black — text/Y on light backgrounds   |
| Amber   | `#d97a3c`| Warm accent (eyebrow text, CTAs)           |
| Forest  | `#0a3d24`| Canonical dark background                  |

## Regenerating the kit

If the source `yander-holding/assets/y-logo.svg` ever changes, rerun:

    python3 yander-holding/build_logo_kit.py

This rebuilds every PNG, favicon, lockup, and social asset from the
single SVG source — so the kit can't drift out of sync.

## Licence

© 2026 Yander. All rights reserved.
